import React, { createContext, useContext, useState, useEffect } from 'react';
import { Customer, Card, Transaction, Language, DataContextType } from '../types';
import { INITIAL_CUSTOMERS, INITIAL_CARDS, INITIAL_TRANSACTIONS } from '../constants';

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [cards, setCards] = useState<Card[]>(INITIAL_CARDS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [language, setLanguage] = useState<Language>('en');

  // Calculation Helpers
  const getCustomerDebt = (customerId: string) => {
    // Find all cards for customer
    const customerCardIds = cards.filter(c => c.customerId === customerId).map(c => c.id);
    
    // Find all UNPAID transactions for those cards
    const unpaidTx = transactions.filter(t => 
      customerCardIds.includes(t.cardId) && t.status === 'unpaid'
    );

    // Debt should ONLY be the Rolling Amount, NOT including the Fee
    const debt = unpaidTx.reduce((sum, t) => sum + t.rollingAmount, 0);
    const fee = unpaidTx.reduce((sum, t) => sum + t.serviceFee, 0);

    return { debt, fee };
  };

  const getCardDebt = (cardId: string) => {
     const unpaidTx = transactions.filter(t => 
      t.cardId === cardId && t.status === 'unpaid'
    );
    // Debt should ONLY be the Rolling Amount, NOT including the Fee
    const debt = unpaidTx.reduce((sum, t) => sum + t.rollingAmount, 0);
    const fee = unpaidTx.reduce((sum, t) => sum + t.serviceFee, 0);
    return { debt, fee };
  };

  // Actions
  const addCustomer = (customer: Customer) => {
    setCustomers(prev => [...prev, customer]);
  };

  const deleteCustomer = (id: string) => {
    setCustomers(prev => prev.filter(c => c.id !== id));
    // Cascade delete cards and transactions
    const customerCardIds = cards.filter(c => c.customerId === id).map(c => c.id);
    setCards(prev => prev.filter(c => c.customerId !== id));
    setTransactions(prev => prev.filter(t => !customerCardIds.includes(t.cardId)));
  };

  const addCard = (card: Card) => {
    setCards(prev => [...prev, card]);
  };

  const updateCard = (card: Card) => {
    setCards(prev => prev.map(c => c.id === card.id ? card : c));
  };

  const deleteCard = (id: string) => {
    setCards(prev => prev.filter(c => c.id !== id));
    setTransactions(prev => prev.filter(t => t.cardId !== id));
  };

  const addTransaction = (transaction: Transaction) => {
    setTransactions(prev => [transaction, ...prev]);
  };

  const updateTransaction = (transaction: Transaction) => {
    setTransactions(prev => prev.map(t => t.id === transaction.id ? transaction : t));
  };

  const confirmPayment = (transactionId: string) => {
    setTransactions(prev => prev.map(t => 
      t.id === transactionId ? { ...t, status: 'paid' } : t
    ));
  };

  return (
    <DataContext.Provider value={{
      customers,
      cards,
      transactions,
      language,
      setLanguage,
      addCustomer,
      deleteCustomer,
      addCard,
      updateCard,
      deleteCard,
      addTransaction,
      updateTransaction,
      confirmPayment,
      getCustomerDebt,
      getCardDebt
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error("useData must be used within a DataProvider");
  return context;
};