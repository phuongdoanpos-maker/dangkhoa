import React, { useState } from 'react';
import { useData } from '../services/dataContext';
import { TRANSLATIONS } from '../constants';
import { Customer, Card, Transaction } from '../types';
import { Plus, Trash2, ChevronDown, ChevronUp, CheckCircle, XCircle, CreditCard as CardIcon, Edit2, Check, X, Edit } from 'lucide-react';

interface CustomerDetailProps {
  customer: Customer;
  onBack: () => void;
}

const CustomerDetail: React.FC<CustomerDetailProps> = ({ customer, onBack }) => {
  const { cards, transactions, language, addCard, updateCard, deleteCard, addTransaction, updateTransaction, confirmPayment, getCardDebt } = useData();
  const t = TRANSLATIONS[language];
  
  // Modal State
  const [showCardModal, setShowCardModal] = useState(false);
  const [editingCard, setEditingCard] = useState<Card | null>(null);

  const customerCards = cards.filter(c => c.customerId === customer.id);
  
  // Formatters
  const formatCurrency = (val: number) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);
  const formatDate = (dateStr: string) => new Date(dateStr).toLocaleDateString();

  // Card Form State (Shared for Add and Edit)
  const [cardForm, setCardForm] = useState<Partial<Card>>({
    ownerName: customer.name,
    bank: '',
    creditLimit: 0,
    dueDate: 1,
    status: 'active'
  });

  const openAddCard = () => {
    setEditingCard(null);
    setCardForm({
        ownerName: customer.name,
        bank: '',
        creditLimit: 0,
        dueDate: 1,
        status: 'active'
    });
    setShowCardModal(true);
  };

  const openEditCard = (card: Card) => {
    setEditingCard(card);
    setCardForm({ ...card });
    setShowCardModal(true);
  };

  const handleSaveCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (cardForm.bank && cardForm.creditLimit) {
      if (editingCard) {
          // Update existing
          updateCard({
              ...editingCard,
              ownerName: cardForm.ownerName!,
              bank: cardForm.bank,
              creditLimit: Number(cardForm.creditLimit),
              dueDate: Number(cardForm.dueDate),
          });
      } else {
          // Add new
          addCard({
            id: Math.random().toString(36).substr(2, 9),
            customerId: customer.id,
            ownerName: cardForm.ownerName || customer.name,
            bank: cardForm.bank!,
            creditLimit: Number(cardForm.creditLimit),
            dueDate: Number(cardForm.dueDate),
            status: 'active'
          });
      }
      setShowCardModal(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="text-slate-500 hover:text-blue-600 font-medium flex items-center gap-1">
          ← {t.customers}
        </button>
        <div className="flex gap-2">
            <button 
                onClick={openAddCard}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-medium transition-colors"
            >
                <Plus size={16} /> {t.addCard}
            </button>
        </div>
      </div>

      {/* Customer Info */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800">{customer.name}</h2>
        <div className="flex gap-6 mt-2 text-sm text-slate-500">
          <span><span className="font-semibold text-slate-700">{t.phone}:</span> {customer.phone}</span>
          <span><span className="font-semibold text-slate-700">{t.notes}:</span> {customer.notes || '-'}</span>
        </div>
      </div>

      {/* Cards List */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-700">{t.cards}</h3>
        {customerCards.length === 0 ? (
            <div className="text-center py-10 bg-white rounded-lg border border-dashed border-slate-300 text-slate-400">
                {t.noData}
            </div>
        ) : (
            customerCards.map(card => (
                <CardItem 
                    key={card.id} 
                    card={card} 
                    transactions={transactions.filter(tr => tr.cardId === card.id)}
                    t={t}
                    onDelete={() => deleteCard(card.id)}
                    onEdit={() => openEditCard(card)}
                    onPay={(tid) => confirmPayment(tid)}
                    onAddTransaction={(tx) => addTransaction(tx)}
                    onUpdateTransaction={(tx) => updateTransaction(tx)}
                    formatCurrency={formatCurrency}
                    formatDate={formatDate}
                    getDebt={() => getCardDebt(card.id)}
                />
            ))
        )}
      </div>

      {/* Add/Edit Card Modal */}
      {showCardModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-bold mb-4">{editingCard ? t.editCard : t.addCard}</h3>
            <form onSubmit={handleSaveCard} className="space-y-3">
              <input 
                type="text" placeholder={t.bank} className="w-full border p-2 rounded" required
                value={cardForm.bank} onChange={e => setCardForm({...cardForm, bank: e.target.value})}
              />
               <input 
                type="text" placeholder={t.owner} className="w-full border p-2 rounded" required
                value={cardForm.ownerName} onChange={e => setCardForm({...cardForm, ownerName: e.target.value})}
              />
              <input 
                type="number" placeholder={t.creditLimit} className="w-full border p-2 rounded" required
                value={cardForm.creditLimit || ''}
                onChange={e => setCardForm({...cardForm, creditLimit: Number(e.target.value)})}
              />
              <div className="flex items-center gap-2">
                  <label className="text-sm text-slate-600">{t.dueDate} (Day):</label>
                  <input 
                    type="number" min="1" max="31" className="border p-2 rounded w-20" required
                    value={cardForm.dueDate} onChange={e => setCardForm({...cardForm, dueDate: Number(e.target.value)})}
                />
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <button type="button" onClick={() => setShowCardModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded">{t.cancel}</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">{t.save}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const CardItem: React.FC<{
    card: Card;
    transactions: Transaction[];
    t: any;
    onDelete: () => void;
    onEdit: () => void;
    onPay: (id: string) => void;
    onAddTransaction: (tx: Transaction) => void;
    onUpdateTransaction: (tx: Transaction) => void;
    formatCurrency: (n: number) => string;
    formatDate: (s: string) => string;
    getDebt: () => {debt: number};
}> = ({ card, transactions, t, onDelete, onEdit, onPay, onAddTransaction, onUpdateTransaction, formatCurrency, formatDate, getDebt }) => {
    const [expanded, setExpanded] = useState(false);
    const [showAddTx, setShowAddTx] = useState(false);
    
    // Add Tx State
    const [newTx, setNewTx] = useState({ amount: '', feePercent: '' });
    
    // Edit Tx State
    const [editingTxId, setEditingTxId] = useState<string | null>(null);
    const [editForm, setEditForm] = useState<Transaction | null>(null);

    const sortedTx = [...transactions].sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());
    const { debt } = getDebt();

    const handleAddTx = (e: React.FormEvent) => {
        e.preventDefault();
        const amount = Number(newTx.amount);
        const feeP = Number(newTx.feePercent);
        const feeAmt = amount * (feeP / 100);

        onAddTransaction({
            id: Math.random().toString(36).substr(2, 9),
            cardId: card.id,
            rollingAmount: amount,
            feePercentage: feeP,
            serviceFee: feeAmt,
            transactionDate: new Date().toISOString(),
            status: 'unpaid'
        });
        setShowAddTx(false);
        setNewTx({ amount: '', feePercent: '' });
        setExpanded(true); 
    };

    const startEditing = (tx: Transaction) => {
        setEditingTxId(tx.id);
        setEditForm({ ...tx });
    };

    const saveEdit = () => {
        if (editForm) {
            // Recalculate fee if amount or percent changed
            const amount = Number(editForm.rollingAmount);
            const feeP = Number(editForm.feePercentage);
            const feeAmt = amount * (feeP / 100);
            
            onUpdateTransaction({
                ...editForm,
                rollingAmount: amount,
                feePercentage: feeP,
                serviceFee: feeAmt
            });
            setEditingTxId(null);
            setEditForm(null);
        }
    };

    const cancelEdit = () => {
        setEditingTxId(null);
        setEditForm(null);
    };

    return (
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden transition-all duration-200 hover:shadow-md">
            {/* Card Header */}
            <div className="p-4 flex items-center justify-between cursor-pointer bg-slate-50" onClick={() => setExpanded(!expanded)}>
                <div className="flex items-center gap-4">
                    <div className="bg-white p-2 rounded-full border border-slate-200 text-blue-600">
                        <CardIcon size={24} />
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-800">{card.bank} <span className="text-slate-400 font-normal text-sm">| {card.ownerName}</span></h4>
                        <div className="text-xs text-slate-500 mt-1 flex gap-3">
                           <span>{t.creditLimit}: {formatCurrency(card.creditLimit)}</span>
                           <span>{t.dueDate}: {card.dueDate}th</span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    {debt > 0 && (
                        <div className="text-right">
                             <p className="text-xs text-slate-500 uppercase font-semibold">{t.outstandingDebt}</p>
                             <p className="text-red-600 font-bold">{formatCurrency(debt)}</p>
                        </div>
                    )}
                    {expanded ? <ChevronUp className="text-slate-400" /> : <ChevronDown className="text-slate-400" />}
                </div>
            </div>

            {/* Expanded Content */}
            {expanded && (
                <div className="p-4 border-t border-slate-100 bg-white">
                    <div className="flex justify-between items-center mb-4">
                        <h5 className="font-semibold text-sm text-slate-700 uppercase tracking-wide flex items-center gap-2">
                             {t.rollingHistory}
                             <span className="text-xs font-normal text-slate-400 normal-case">({t.doubleClickEdit})</span>
                        </h5>
                        <div className="flex gap-2">
                            <button 
                                onClick={(e) => { e.stopPropagation(); onEdit(); }}
                                className="text-xs text-blue-600 hover:text-blue-800 px-2 py-1 border border-blue-200 rounded flex items-center gap-1"
                            >
                                <Edit size={12} /> {t.editCard}
                            </button>
                            <button 
                                onClick={(e) => { e.stopPropagation(); onDelete(); }}
                                className="text-xs text-red-500 hover:text-red-700 px-2 py-1 border border-red-200 rounded flex items-center gap-1"
                            >
                                <Trash2 size={12} /> {t.delete}
                            </button>
                            <button 
                                onClick={(e) => { e.stopPropagation(); setShowAddTx(true); }}
                                className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1 rounded flex items-center gap-1"
                            >
                                <Plus size={12} /> Transaction
                            </button>
                        </div>
                    </div>

                    {/* Transaction Table */}
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-slate-50 text-slate-500">
                                <tr>
                                    <th className="p-2 rounded-l w-32">{t.date}</th>
                                    <th className="p-2">{t.amount}</th>
                                    <th className="p-2 w-20">{t.feePercent}</th>
                                    <th className="p-2">{t.fee}</th>
                                    <th className="p-2 w-32">{t.status}</th>
                                    <th className="p-2 rounded-r text-right">{t.actions}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sortedTx.map(tx => {
                                    const isEditing = editingTxId === tx.id;
                                    return (
                                        <tr 
                                            key={tx.id} 
                                            className={`border-b border-slate-50 last:border-0 hover:bg-slate-50 ${isEditing ? 'bg-blue-50/50' : ''}`}
                                            onDoubleClick={() => !isEditing && startEditing(tx)}
                                        >
                                            {isEditing && editForm ? (
                                                <>
                                                    <td className="p-2">
                                                        <input 
                                                            type="date" 
                                                            className="w-full border rounded p-1 text-xs"
                                                            value={editForm.transactionDate.split('T')[0]}
                                                            onChange={e => setEditForm({...editForm, transactionDate: new Date(e.target.value).toISOString()})}
                                                        />
                                                    </td>
                                                    <td className="p-2">
                                                        <input 
                                                            type="number" 
                                                            className="w-full border rounded p-1 text-xs"
                                                            value={editForm.rollingAmount}
                                                            onChange={e => setEditForm({...editForm, rollingAmount: Number(e.target.value)})}
                                                        />
                                                    </td>
                                                    <td className="p-2">
                                                        <input 
                                                            type="number" 
                                                            className="w-full border rounded p-1 text-xs"
                                                            value={editForm.feePercentage || 0}
                                                            onChange={e => setEditForm({...editForm, feePercentage: Number(e.target.value)})}
                                                        />
                                                    </td>
                                                    <td className="p-2 text-slate-500 italic text-xs">
                                                        {formatCurrency(editForm.rollingAmount * ((editForm.feePercentage || 0) / 100))}
                                                    </td>
                                                    <td className="p-2">
                                                        <select 
                                                            className="w-full border rounded p-1 text-xs"
                                                            value={editForm.status}
                                                            onChange={e => setEditForm({...editForm, status: e.target.value as 'paid' | 'unpaid'})}
                                                        >
                                                            <option value="paid">{t.paid}</option>
                                                            <option value="unpaid">{t.unpaid}</option>
                                                        </select>
                                                    </td>
                                                    <td className="p-2 text-right">
                                                        <div className="flex justify-end gap-1">
                                                            <button onClick={saveEdit} className="p-1 bg-blue-100 text-blue-600 rounded hover:bg-blue-200"><Check size={14} /></button>
                                                            <button onClick={cancelEdit} className="p-1 bg-red-100 text-red-600 rounded hover:bg-red-200"><X size={14} /></button>
                                                        </div>
                                                    </td>
                                                </>
                                            ) : (
                                                <>
                                                    <td className="p-2 text-slate-600">{formatDate(tx.transactionDate)}</td>
                                                    <td className="p-2 font-bold text-blue-600">{formatCurrency(tx.rollingAmount)}</td>
                                                    <td className="p-2 text-slate-600">{tx.feePercentage || 0}%</td>
                                                    <td className="p-2 text-slate-500">{formatCurrency(tx.serviceFee)}</td>
                                                    <td className="p-2">
                                                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${tx.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                                            {tx.status === 'paid' ? t.paid : t.unpaid}
                                                        </span>
                                                    </td>
                                                    <td className="p-2 text-right">
                                                        {tx.status === 'unpaid' && (
                                                            <button 
                                                                onClick={() => onPay(tx.id)}
                                                                className="bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-1 rounded text-xs font-medium transition-colors"
                                                            >
                                                                {t.confirmPayment}
                                                            </button>
                                                        )}
                                                    </td>
                                                </>
                                            )}
                                        </tr>
                                    );
                                })}
                                {sortedTx.length === 0 && (
                                    <tr>
                                        <td colSpan={6} className="p-4 text-center text-slate-400 italic">{t.noData}</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Add Transaction Modal Inline for simplicity in this demo */}
            {showAddTx && (
                 <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-xl p-6 w-full max-w-sm">
                        <h4 className="font-bold mb-4">New Transaction for {card.bank}</h4>
                        <form onSubmit={handleAddTx} className="space-y-3">
                             <div>
                                <label className="text-xs text-slate-500">{t.amount}</label>
                                <input 
                                    type="number" className="w-full border p-2 rounded" required
                                    value={newTx.amount} onChange={e => setNewTx({...newTx, amount: e.target.value})}
                                />
                             </div>
                             <div>
                                <label className="text-xs text-slate-500">{t.feePercent} (%)</label>
                                <div className="flex items-center gap-2">
                                    <input 
                                        type="number" step="0.01" className="w-full border p-2 rounded" required
                                        value={newTx.feePercent} onChange={e => setNewTx({...newTx, feePercent: e.target.value})}
                                    />
                                    <span className="text-slate-400">%</span>
                                </div>
                             </div>
                             
                             {/* Preview Calc */}
                             {newTx.amount && newTx.feePercent && (
                                <div className="bg-slate-50 p-2 rounded text-right text-sm">
                                    <span className="text-slate-500 mr-2">{t.fee}:</span>
                                    <span className="font-bold text-slate-700">
                                        {formatCurrency(Number(newTx.amount) * (Number(newTx.feePercent) / 100))}
                                    </span>
                                </div>
                             )}

                             <div className="flex justify-end gap-2 mt-4">
                                <button type="button" onClick={() => setShowAddTx(false)} className="px-3 py-1.5 text-sm text-slate-600 hover:bg-slate-100 rounded">{t.cancel}</button>
                                <button type="submit" className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded hover:bg-blue-700">Add</button>
                            </div>
                        </form>
                    </div>
                 </div>
            )}
        </div>
    );
};

export default CustomerDetail;