import React, { useState } from 'react';
import { useData } from '../services/dataContext';
import { TRANSLATIONS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { DollarSign, Wallet, TrendingUp, AlertCircle, Calendar, CreditCard, ChevronDown } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { transactions, customers, cards, language, getCustomerDebt } = useData();
  const t = TRANSLATIONS[language];

  // State for upcoming filter
  const [daysFilter, setDaysFilter] = useState<3 | 5 | 10>(5);

  // Calculate Monthly Stats
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const monthlyTransactions = transactions.filter(tx => {
    const date = new Date(tx.transactionDate);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  });

  const totalRolling = monthlyTransactions.reduce((acc, curr) => acc + curr.rollingAmount, 0);
  const totalFees = monthlyTransactions.reduce((acc, curr) => acc + curr.serviceFee, 0);
  
  // Outstanding Debt (System wide) - Excludes fees now based on context update
  const outstandingDebt = transactions
    .filter(t => t.status === 'unpaid')
    .reduce((acc, t) => acc + t.rollingAmount, 0);

  // Chart Data: Top 5 Customers by Total Credit Limit (Previously Debt)
  const customerCreditData = customers.map(c => {
    // Sum credit limit of all cards for this customer
    const totalLimit = cards
        .filter(card => card.customerId === c.id)
        .reduce((sum, card) => sum + card.creditLimit, 0);
    
    return { name: c.name, limit: totalLimit };
  })
  .filter(item => item.limit > 0)
  .sort((a, b) => b.limit - a.limit)
  .slice(0, 5);

  // Upcoming Cards Logic
  const upcomingCards = cards.map(card => {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth();
    
    // Construct due date for current month
    let nextDueDate = new Date(currentYear, currentMonth, card.dueDate);
    
    // If due date has passed this month, look at next month
    if (nextDueDate < today) {
        nextDueDate = new Date(currentYear, currentMonth + 1, card.dueDate);
    }
    
    const diffTime = Math.abs(nextDueDate.getTime() - today.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
    
    return { ...card, daysRemaining: diffDays, exactDueDate: nextDueDate };
  })
  .filter(card => card.daysRemaining <= daysFilter)
  .sort((a, b) => a.daysRemaining - b.daysRemaining);


  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat(language === 'en' ? 'en-US' : 'vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  const StatCard = ({ title, value, icon: Icon, color }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-start justify-between">
      <div>
        <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-slate-800">{formatCurrency(value)}</h3>
      </div>
      <div className={`p-3 rounded-lg ${color}`}>
        <Icon size={24} className="text-white" />
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-10">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">{t.monthlyOverview}</h2>
        <p className="text-slate-500 text-sm mt-1">{new Date().toLocaleDateString(language === 'en' ? 'en-US' : 'vi-VN', { month: 'long', year: 'numeric' })}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          title={t.totalRolling} 
          value={totalRolling} 
          icon={Wallet} 
          color="bg-blue-500" 
        />
        <StatCard 
          title={t.totalFees} 
          value={totalFees} 
          icon={TrendingUp} 
          color="bg-emerald-500" 
        />
        <StatCard 
          title={t.outstandingDebt} 
          value={outstandingDebt} 
          icon={AlertCircle} 
          color="bg-rose-500" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upcoming Due Cards */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col h-96">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Calendar className="text-orange-500" size={20} />
                    {t.upcomingDue}
                </h3>
                <div className="relative">
                    <select 
                        className="appearance-none bg-slate-50 border border-slate-200 rounded-lg px-3 py-1 text-sm font-medium text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 pr-8"
                        value={daysFilter}
                        onChange={(e) => setDaysFilter(Number(e.target.value) as 3|5|10)}
                    >
                        <option value={3}>3 {t.days}</option>
                        <option value={5}>5 {t.days}</option>
                        <option value={10}>10 {t.days}</option>
                    </select>
                    <ChevronDown className="absolute right-2 top-1.5 text-slate-400 pointer-events-none" size={14} />
                </div>
            </div>
            
            <div className="flex-1 overflow-auto pr-1">
                {upcomingCards.length > 0 ? (
                    <div className="space-y-3">
                        {upcomingCards.map(card => (
                            <div key={card.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-xs">
                                        {card.dueDate}
                                    </div>
                                    <div>
                                        <p className="font-semibold text-slate-800 text-sm">{card.bank}</p>
                                        <p className="text-xs text-slate-500">{card.ownerName}</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs text-slate-500">{t.remaining}</p>
                                    <p className="font-bold text-orange-600">{card.daysRemaining} {t.days}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400">
                        <Calendar size={48} className="mb-2 opacity-20" />
                        <p className="text-sm">No cards due within {daysFilter} days</p>
                    </div>
                )}
            </div>
          </div>

          {/* Top Credit Limits Chart */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-96 flex flex-col">
            <h3 className="text-lg font-bold text-slate-800 mb-6">{t.totalCreditLimit} - Top 5</h3>
            <div className="flex-1 min-h-0">
                <ResponsiveContainer width="100%" height="100%">
                <BarChart data={customerCreditData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" hide />
                    <YAxis type="category" dataKey="name" width={100} tick={{fontSize: 12}} />
                    <Tooltip 
                    formatter={(value: number) => formatCurrency(value)}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar dataKey="limit" radius={[0, 4, 4, 0]}>
                    {customerCreditData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#3b82f6' : '#60a5fa'} />
                        ))}
                    </Bar>
                </BarChart>
                </ResponsiveContainer>
            </div>
          </div>
      </div>
    </div>
  );
};

export default Dashboard;