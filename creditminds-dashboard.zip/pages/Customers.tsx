import React, { useState } from 'react';
import { useData } from '../services/dataContext';
import { TRANSLATIONS } from '../constants';
import { Search, Plus, User, Phone, DollarSign, ChevronRight } from 'lucide-react';
import CustomerDetail from './CustomerDetail';
import { Customer } from '../types';

const Customers: React.FC = () => {
  const { customers, language, addCustomer, getCustomerDebt } = useData();
  const t = TRANSLATIONS[language];
  
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newCustomer, setNewCustomer] = useState({ name: '', phone: '', notes: '' });

  // Filter Logic
  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.phone.includes(searchTerm)
  );

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if(newCustomer.name && newCustomer.phone) {
        addCustomer({
            id: Math.random().toString(36).substr(2, 9),
            ...newCustomer
        });
        setIsAdding(false);
        setNewCustomer({ name: '', phone: '', notes: '' });
    }
  };

  const formatCurrency = (val: number) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);

  if (selectedCustomer) {
    return <CustomerDetail customer={selectedCustomer} onBack={() => setSelectedCustomer(null)} />;
  }

  return (
    <div className="space-y-6">
      {/* Top Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-slate-800">{t.customers}</h2>
        <div className="flex gap-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
                <input 
                    type="text" 
                    placeholder={t.search} 
                    className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <button 
                onClick={() => setIsAdding(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-medium transition-colors"
            >
                <Plus size={18} /> <span className="hidden md:inline">{t.addCustomer}</span>
            </button>
        </div>
      </div>

      {/* Customer List Table/Cards */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                    <tr>
                        <th className="p-4 font-medium">{t.name}</th>
                        <th className="p-4 font-medium">{t.phone}</th>
                        <th className="p-4 font-medium text-right">{t.totalDebt}</th>
                        <th className="p-4 font-medium text-right">{t.actions}</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredCustomers.length > 0 ? filteredCustomers.map(c => {
                        const { debt, fee } = getCustomerDebt(c.id);
                        return (
                            <tr key={c.id} className="hover:bg-slate-50 transition-colors group">
                                <td className="p-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">
                                            {c.name.charAt(0)}
                                        </div>
                                        <div>
                                            <p className="font-semibold text-slate-800">{c.name}</p>
                                            {c.notes && <p className="text-xs text-slate-400">{c.notes}</p>}
                                        </div>
                                    </div>
                                </td>
                                <td className="p-4 text-slate-600 font-mono">{c.phone}</td>
                                <td className="p-4 text-right">
                                    <div className={`font-medium ${debt > 0 ? 'text-red-600' : 'text-slate-400'}`}>
                                        {formatCurrency(debt)}
                                    </div>
                                    {fee > 0 && <div className="text-xs text-slate-400">Fees: {formatCurrency(fee)}</div>}
                                </td>
                                <td className="p-4 text-right">
                                    <button 
                                        onClick={() => setSelectedCustomer(c)}
                                        className="text-blue-600 hover:text-blue-800 font-medium inline-flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                        {t.viewDetails} <ChevronRight size={14} />
                                    </button>
                                </td>
                            </tr>
                        );
                    }) : (
                        <tr>
                            <td colSpan={4} className="p-8 text-center text-slate-400">
                                {t.noData}
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {isAdding && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl">
                  <h3 className="text-xl font-bold mb-4 text-slate-800">{t.addCustomer}</h3>
                  <form onSubmit={handleAdd} className="space-y-4">
                      <div>
                          <label className="block text-sm font-medium text-slate-600 mb-1">{t.name}</label>
                          <div className="relative">
                            <User className="absolute left-3 top-3 text-slate-400" size={16} />
                            <input 
                                className="w-full pl-10 p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
                                required 
                                value={newCustomer.name}
                                onChange={e => setNewCustomer({...newCustomer, name: e.target.value})}
                            />
                          </div>
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-600 mb-1">{t.phone}</label>
                          <div className="relative">
                             <Phone className="absolute left-3 top-3 text-slate-400" size={16} />
                             <input 
                                className="w-full pl-10 p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
                                required 
                                value={newCustomer.phone}
                                onChange={e => setNewCustomer({...newCustomer, phone: e.target.value})}
                             />
                          </div>
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-600 mb-1">{t.notes}</label>
                          <textarea 
                            className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
                            rows={3}
                            value={newCustomer.notes}
                            onChange={e => setNewCustomer({...newCustomer, notes: e.target.value})}
                          />
                      </div>
                      <div className="flex justify-end gap-3 pt-2">
                          <button type="button" onClick={() => setIsAdding(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">{t.cancel}</button>
                          <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md shadow-blue-200">{t.save}</button>
                      </div>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};

export default Customers;
