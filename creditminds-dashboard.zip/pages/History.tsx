import React, { useState } from 'react';
import { useData } from '../services/dataContext';
import { TRANSLATIONS } from '../constants';
import { Search, Filter, Calendar } from 'lucide-react';

const History: React.FC = () => {
  const { transactions, cards, customers, language } = useData();
  const t = TRANSLATIONS[language];

  // Filters State
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Formatters
  const formatCurrency = (val: number) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);
  const formatDate = (dateStr: string) => new Date(dateStr).toLocaleDateString();

  // Combine data sources
  const enrichedTransactions = transactions.map(tx => {
    const card = cards.find(c => c.id === tx.cardId);
    const customer = customers.find(c => c.id === card?.customerId);
    return {
      ...tx,
      card,
      customer
    };
  });

  // Filtering Logic
  const filteredTransactions = enrichedTransactions.filter(item => {
    const matchesSearch = 
      (item.customer?.name.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (item.card?.bank.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (item.card?.ownerName.toLowerCase() || '').includes(searchTerm.toLowerCase());

    const txDate = new Date(item.transactionDate);
    // Reset time for accurate date comparison
    txDate.setHours(0,0,0,0);

    let matchesStart = true;
    if (startDate) {
        const start = new Date(startDate);
        start.setHours(0,0,0,0);
        matchesStart = txDate >= start;
    }

    let matchesEnd = true;
    if (endDate) {
        const end = new Date(endDate);
        end.setHours(23,59,59,999);
        matchesEnd = txDate <= end;
    }

    return matchesSearch && matchesStart && matchesEnd;
  }).sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());

  // Totals for filtered view
  const totalAmountFiltered = filteredTransactions.reduce((acc, curr) => acc + curr.rollingAmount, 0);
  const totalFeesFiltered = filteredTransactions.reduce((acc, curr) => acc + curr.serviceFee, 0);

  const clearFilters = () => {
      setSearchTerm('');
      setStartDate('');
      setEndDate('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-bold text-slate-800">{t.history}</h2>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col md:flex-row gap-4 items-end md:items-center">
         
         {/* Text Search */}
         <div className="flex-1 w-full">
            <label className="text-xs text-slate-500 font-medium mb-1 block">{t.search}</label>
            <div className="relative">
                <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
                <input 
                    type="text" 
                    placeholder={t.searchHistory} 
                    className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
         </div>

         {/* Date From */}
         <div className="w-full md:w-48">
             <label className="text-xs text-slate-500 font-medium mb-1 block">{t.fromDate}</label>
             <div className="relative">
                 <Calendar className="absolute left-3 top-2.5 text-slate-400" size={18} />
                 <input 
                    type="date"
                    className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                 />
             </div>
         </div>

         {/* Date To */}
         <div className="w-full md:w-48">
             <label className="text-xs text-slate-500 font-medium mb-1 block">{t.toDate}</label>
             <div className="relative">
                 <Calendar className="absolute left-3 top-2.5 text-slate-400" size={18} />
                 <input 
                    type="date"
                    className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                 />
             </div>
         </div>

         {/* Clear Button */}
         <button 
            onClick={clearFilters}
            className="px-4 py-2 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 text-sm font-medium transition-colors"
         >
            {t.clearFilters}
         </button>
      </div>

      {/* Summary for Filtered Results */}
      {(searchTerm || startDate || endDate) && (
          <div className="flex gap-6 p-4 bg-blue-50 border border-blue-100 rounded-lg">
               <div>
                   <p className="text-xs text-blue-600 uppercase font-bold">{t.amount}</p>
                   <p className="text-xl font-bold text-blue-800">{formatCurrency(totalAmountFiltered)}</p>
               </div>
               <div>
                   <p className="text-xs text-blue-600 uppercase font-bold">{t.totalFees}</p>
                   <p className="text-xl font-bold text-blue-800">{formatCurrency(totalFeesFiltered)}</p>
               </div>
          </div>
      )}

      {/* History Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
         <div className="overflow-x-auto">
             <table className="w-full text-left border-collapse">
                 <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                     <tr>
                         <th className="p-4 font-medium">{t.date}</th>
                         <th className="p-4 font-medium">{t.name}</th>
                         <th className="p-4 font-medium">{t.bank}</th>
                         <th className="p-4 font-medium">{t.amount}</th>
                         <th className="p-4 font-medium">{t.feePercent}</th>
                         <th className="p-4 font-medium">{t.fee}</th>
                         <th className="p-4 font-medium">{t.status}</th>
                     </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100 text-sm">
                     {filteredTransactions.length > 0 ? (
                         filteredTransactions.map(tx => (
                             <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                                 <td className="p-4 text-slate-600">{formatDate(tx.transactionDate)}</td>
                                 <td className="p-4 font-medium text-slate-800">
                                     {tx.customer?.name || 'Unknown'}
                                     <span className="block text-xs text-slate-400 font-normal">{tx.customer?.phone}</span>
                                 </td>
                                 <td className="p-4 text-slate-700">
                                     {tx.card?.bank}
                                     <span className="block text-xs text-slate-400">{tx.card?.ownerName}</span>
                                 </td>
                                 <td className="p-4 font-bold text-blue-600">
                                     {formatCurrency(tx.rollingAmount)}
                                 </td>
                                 <td className="p-4 text-slate-600">{tx.feePercentage}%</td>
                                 <td className="p-4 text-slate-600">{formatCurrency(tx.serviceFee)}</td>
                                 <td className="p-4">
                                     <span className={`px-2 py-1 rounded-full text-xs font-medium ${tx.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                         {tx.status === 'paid' ? t.paid : t.unpaid}
                                     </span>
                                 </td>
                             </tr>
                         ))
                     ) : (
                         <tr>
                             <td colSpan={7} className="p-8 text-center text-slate-400">
                                 {t.noData}
                             </td>
                         </tr>
                     )}
                 </tbody>
             </table>
         </div>
      </div>
    </div>
  );
};

export default History;