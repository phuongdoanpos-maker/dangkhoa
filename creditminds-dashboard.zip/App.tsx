import React, { useState } from 'react';
import { DataProvider } from './services/dataContext';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import History from './pages/History';
import { PageType } from './types';

function App() {
  const [activePage, setActivePage] = useState<PageType>('dashboard');

  return (
    <DataProvider>
      <Layout activePage={activePage} onNavigate={setActivePage}>
        {activePage === 'dashboard' && <Dashboard />}
        {activePage === 'customers' && <Customers />}
        {activePage === 'history' && <History />}
      </Layout>
    </DataProvider>
  );
}

export default App;