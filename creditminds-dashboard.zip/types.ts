export interface Customer {
  id: string;
  name: string;
  phone: string;
  notes?: string;
}

export interface Card {
  id: string;
  customerId: string;
  ownerName: string; // Sometimes card owner name differs from customer name
  bank: string;
  creditLimit: number;
  dueDate: number; // Day of month (1-31)
  status: 'active' | 'inactive';
}

export interface Transaction {
  id: string;
  cardId: string;
  rollingAmount: number;
  feePercentage: number; // New field
  serviceFee: number; // Calculated amount
  transactionDate: string; // ISO Date string
  status: 'paid' | 'unpaid';
}

export type Language = 'en' | 'vi';

export interface DashboardStats {
  totalRolling: number;
  totalFees: number;
  outstandingDebt: number;
}

// Data Context Interface
export interface DataContextType {
  customers: Customer[];
  cards: Card[];
  transactions: Transaction[];
  language: Language;
  setLanguage: (lang: Language) => void;
  addCustomer: (customer: Customer) => void;
  deleteCustomer: (id: string) => void;
  addCard: (card: Card) => void;
  updateCard: (card: Card) => void; 
  deleteCard: (id: string) => void;
  addTransaction: (transaction: Transaction) => void;
  updateTransaction: (transaction: Transaction) => void;
  confirmPayment: (transactionId: string) => void;
  getCustomerDebt: (customerId: string) => { debt: number; fee: number };
  getCardDebt: (cardId: string) => { debt: number; fee: number };
}

export type PageType = 'dashboard' | 'customers' | 'history';