import React from 'react';
import { useData } from '../services/dataContext';
import { TRANSLATIONS } from '../constants';
import { LayoutDashboard, Users, CreditCard, Languages, History } from 'lucide-react';
import { PageType } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activePage: PageType;
  onNavigate: (page: PageType) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activePage, onNavigate }) => {
  const { language, setLanguage } = useData();
  const t = TRANSLATIONS[language];

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex-shrink-0 hidden md:flex flex-col">
        <div className="p-6 border-b border-slate-700">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <CreditCard className="text-blue-400" />
            CreditMinds
          </h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => onNavigate('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              activePage === 'dashboard' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <LayoutDashboard size={20} />
            {t.dashboard}
          </button>
          
          <button 
            onClick={() => onNavigate('customers')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              activePage === 'customers' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Users size={20} />
            {t.customers}
          </button>

          <button 
            onClick={() => onNavigate('history')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              activePage === 'history' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <History size={20} />
            {t.history}
          </button>
        </nav>

        <div className="p-4 border-t border-slate-700">
          <button 
            onClick={() => setLanguage(language === 'en' ? 'vi' : 'en')}
            className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition-colors"
          >
            <Languages size={16} />
            {language === 'en' ? 'Tiếng Việt' : 'English'}
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white border-b border-slate-200 p-4 md:hidden flex justify-between items-center">
          <span className="font-bold text-slate-800">CreditMinds</span>
          <button onClick={() => setLanguage(language === 'en' ? 'vi' : 'en')} className="p-2">
             <Languages size={20} />
          </button>
        </header>

        {/* Mobile Nav */}
         <div className="bg-white border-b border-slate-200 p-2 md:hidden flex justify-around">
            <button 
              onClick={() => onNavigate('dashboard')}
              className={`p-2 rounded ${activePage === 'dashboard' ? 'bg-blue-50 text-blue-600' : 'text-slate-600'}`}
            >
              <LayoutDashboard />
            </button>
            <button 
              onClick={() => onNavigate('customers')}
               className={`p-2 rounded ${activePage === 'customers' ? 'bg-blue-50 text-blue-600' : 'text-slate-600'}`}
            >
              <Users />
            </button>
            <button 
              onClick={() => onNavigate('history')}
               className={`p-2 rounded ${activePage === 'history' ? 'bg-blue-50 text-blue-600' : 'text-slate-600'}`}
            >
              <History />
            </button>
         </div>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-4 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;